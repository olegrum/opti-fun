var searchData=
[
  ['log2',['log2',['../main_8cpp.html#a38bd88274dc5594b4826fd60c8054c8e',1,'main.cpp']]]
];
