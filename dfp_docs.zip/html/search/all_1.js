var searchData=
[
  ['dfpmin',['dfpmin',['../main_8cpp.html#a398baed6dfa9951dd231ef97728495e4',1,'main.cpp']]]
];
