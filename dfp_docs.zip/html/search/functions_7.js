var searchData=
[
  ['operator_2a',['operator*',['../main_8cpp.html#a59cbec7facb1e7501bf85282bd086c72',1,'operator*(const double s, const Vector &amp;v):&#160;main.cpp'],['../main_8cpp.html#afd528169ad61eabfb3c1d2becb66be55',1,'operator*(const Vector &amp;v, const double s):&#160;main.cpp'],['../main_8cpp.html#aa4fcaeaef1ca3d10a1b4c35f93f16aff',1,'operator*(const Matrix &amp;A, const Vector &amp;x):&#160;main.cpp']]],
  ['operator_2b',['operator+',['../main_8cpp.html#a06ca8cbab2b706b2a4e6b21ed24e0087',1,'main.cpp']]],
  ['operator_2d',['operator-',['../main_8cpp.html#ac7a74ab9b64a6ddb03e7d25895c2699d',1,'operator-(const Vector &amp;v):&#160;main.cpp'],['../main_8cpp.html#a885f29c16d9844e1629e3f4c89cf5499',1,'operator-(const Vector &amp;v1, const Vector &amp;v2):&#160;main.cpp']]],
  ['operator_2f',['operator/',['../main_8cpp.html#a116b1344de33af764b4f89c002d0ed78',1,'main.cpp']]]
];
