var searchData=
[
  ['icreatematrix',['ICreateMatrix',['../main_8cpp.html#ada03b290bec98b3b3c5fe7f2f55a9e04',1,'main.cpp']]],
  ['idestroymatrix',['IDestroyMatrix',['../main_8cpp.html#a9a37945f1a3be49ce3f5f7280b6b515e',1,'main.cpp']]]
];
