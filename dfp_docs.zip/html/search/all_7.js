var searchData=
[
  ['sqr',['SQR',['../main_8cpp.html#ad41630f833e920c1ffa34722f45a8e77',1,'main.cpp']]],
  ['stpmx',['STPMX',['../main_8cpp.html#a015c68c354ae47a20d4f552f4ad8b67b',1,'main.cpp']]]
];
